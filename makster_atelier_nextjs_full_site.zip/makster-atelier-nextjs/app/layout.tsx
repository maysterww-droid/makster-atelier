import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://maksteratelier.eu"),
  title: {
    default: "MAKSTER ATELIER | Premium Bespoke Furniture & Interiors",
    template: "%s | MAKSTER ATELIER",
  },
  description:
    "Premium bespoke kitchens, wardrobes and custom interiors designed, manufactured and installed by MAKSTER ATELIER in Prague and across Europe.",
  keywords: [
    "bespoke furniture Prague",
    "custom kitchen Prague",
    "nábytek na míru Praha",
    "kuchyně na míru Praha",
    "wardrobes Prague",
    "interior studio Prague",
    "MAKSTER ATELIER",
  ],
  openGraph: {
    title: "MAKSTER ATELIER",
    description: "Premium bespoke furniture and interiors crafted around your life.",
    url: "https://maksteratelier.eu",
    siteName: "MAKSTER ATELIER",
    images: [{ url: "/images/hero-kitchen.png", width: 1200, height: 1600 }],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "MAKSTER ATELIER",
    description: "Premium bespoke furniture and interiors crafted around your life.",
    images: ["/images/hero-kitchen.png"],
  },
  alternates: {
    canonical: "https://maksteratelier.eu",
    languages: {
      en: "https://maksteratelier.eu",
      cs: "https://maksteratelier.eu?lang=cz",
      ru: "https://maksteratelier.eu?lang=ru",
    },
  },
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/icon-192.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#050505",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

"use client";

import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import {
  ArrowRight,
  Calculator,
  Check,
  ChevronLeft,
  ChevronRight,
  Globe2,
  Menu,
  MessageCircle,
  Moon,
  Phone,
  Play,
  Send,
  Settings,
  Star,
  Sun,
  X,
} from "lucide-react";
import Image from "next/image";
import { useMemo, useState } from "react";

type Lang = "en" | "cz" | "ru";
type Theme = "dark" | "light";

const copy = {
  en: {
    nav: ["Services", "Portfolio", "Calculator", "Booking", "Reviews"],
    heroEyebrow: "Premium bespoke interiors",
    heroTitle: "Crafted Around Your Life",
    heroText:
      "Bespoke kitchens, wardrobes and interiors designed, manufactured and installed by MAKSTER ATELIER in Prague and across Europe.",
    viewProjects: "View Projects",
    calculate: "Calculate Kitchen",
    servicesEyebrow: "Our Services",
    servicesTitle: "Bespoke Furniture Tailored to You",
    aboutTitle: "We create spaces that inspire",
    aboutText:
      "MAKSTER ATELIER is a premium furniture and interior studio based in Prague. From concept to installation, every detail is crafted with precision, functionality and timeless aesthetics.",
    processTitle: "From idea to installation",
    portfolioTitle: "Selected Projects",
    foundersTitle: "The people behind the atelier",
    bookingTitle: "Book a Free Consultation",
    bookingText: "Send basic project details and we will contact you to arrange a consultation or measurement.",
    areaTitle: "Prague, Czech Republic & Europe",
    reviewsTitle: "Client Trust",
    calculatorTitle: "Detailed Kitchen Budget Estimator",
    calculatorText:
      "Answer a few questions and receive an approximate kitchen budget with a clear breakdown.",
    quote: "Request Detailed Quote",
    notIncluded:
      "Not included: plumbing, electrical works, wall preparation, tiles, stone wall panels and special hidden systems unless agreed separately.",
    admin: "Admin Panel",
    light: "Light",
    dark: "Dark",
  },
  cz: {
    nav: ["Služby", "Portfolio", "Kalkulačka", "Zaměření", "Recenze"],
    heroEyebrow: "Prémiové interiéry na míru",
    heroTitle: "Vytvořeno kolem vašeho života",
    heroText:
      "Kuchyně, šatny a interiéry na míru navržené, vyrobené a namontované MAKSTER ATELIER v Praze a po Evropě.",
    viewProjects: "Zobrazit projekty",
    calculate: "Spočítat kuchyni",
    servicesEyebrow: "Naše služby",
    servicesTitle: "Nábytek na míru přizpůsobený vám",
    aboutTitle: "Tvoříme prostory, které inspirují",
    aboutText:
      "MAKSTER ATELIER je prémiové studio nábytku a interiérů se sídlem v Praze. Od konceptu až po montáž řešíme každý detail s důrazem na přesnost, funkčnost a nadčasovou estetiku.",
    processTitle: "Od nápadu až po montáž",
    portfolioTitle: "Vybrané projekty",
    foundersTitle: "Lidé za ateliérem",
    bookingTitle: "Objednat bezplatnou konzultaci",
    bookingText: "Pošlete nám základní informace o projektu a ozveme se vám kvůli konzultaci nebo zaměření.",
    areaTitle: "Praha, Česká republika a Evropa",
    reviewsTitle: "Důvěra klientů",
    calculatorTitle: "Podrobný odhad rozpočtu kuchyně",
    calculatorText:
      "Odpovězte na několik otázek a získejte orientační rozpočet kuchyně s jasným rozpisem.",
    quote: "Odeslat poptávku",
    notIncluded:
      "Není zahrnuto: instalatérské práce, elektroinstalace, příprava stěn, obklady, kamenné obklady a speciální skryté systémy, pokud není dohodnuto jinak.",
    admin: "Administrace",
    light: "Světlý",
    dark: "Tmavý",
  },
  ru: {
    nav: ["Услуги", "Портфолио", "Калькулятор", "Замер", "Отзывы"],
    heroEyebrow: "Премиальные интерьеры на заказ",
    heroTitle: "Создано вокруг вашей жизни",
    heroText:
      "Кухни, гардеробные и интерьеры на заказ, которые MAKSTER ATELIER проектирует, производит и монтирует в Праге и по Европе.",
    viewProjects: "Смотреть проекты",
    calculate: "Рассчитать кухню",
    servicesEyebrow: "Наши услуги",
    servicesTitle: "Мебель на заказ под ваш образ жизни",
    aboutTitle: "Создаём пространства, которые вдохновляют",
    aboutText:
      "MAKSTER ATELIER — премиальная студия мебели и интерьеров на заказ в Праге. От концепции до монтажа мы контролируем каждую деталь: точность, функциональность и эстетику вне времени.",
    processTitle: "От идеи до монтажа",
    portfolioTitle: "Избранные проекты",
    foundersTitle: "Люди за ателье",
    bookingTitle: "Записаться на бесплатную консультацию",
    bookingText: "Отправьте базовую информацию о проекте, и мы свяжемся с вами для консультации или замера.",
    areaTitle: "Прага, Чехия и Европа",
    reviewsTitle: "Доверие клиентов",
    calculatorTitle: "Детальный расчёт бюджета кухни",
    calculatorText:
      "Ответьте на несколько вопросов и получите ориентировочный бюджет кухни с понятной разбивкой.",
    quote: "Отправить запрос",
    notIncluded:
      "Не включено: сантехнические работы, электрика, подготовка стен, плитка, каменные стеновые панели и специальные скрытые системы, если не согласовано отдельно.",
    admin: "Админ-панель",
    light: "Светлая",
    dark: "Тёмная",
  },
};

const services = [
  ["Kitchens", "Premium kitchens designed around everyday comfort and timeless aesthetics."],
  ["Wardrobes", "Walk-in closets, wardrobes and storage systems made to measure."],
  ["Custom Furniture", "TV walls, cabinets, commercial furniture and bespoke interior details."],
  ["Complete Interiors", "From concept and design to production and final installation."],
];

const process = ["Consultation", "Design", "Production", "Installation"];

const initialProjects = [
  { id: 1, title: "Premium Kitchen", category: "kitchen", image: "/images/hero-kitchen.png", height: "h-[440px]" },
  { id: 2, title: "Walk-in Wardrobe", category: "wardrobe", image: "/images/hero-kitchen.png", height: "h-[320px]" },
  { id: 3, title: "Bespoke Interior", category: "custom", image: "/images/hero-kitchen.png", height: "h-[380px]" },
  { id: 4, title: "Dark Kitchen Concept", category: "kitchen", image: "/images/hero-kitchen.png", height: "h-[300px]" },
  { id: 5, title: "Storage Wall", category: "wardrobe", image: "/images/hero-kitchen.png", height: "h-[460px]" },
];

const reviews = [
  {
    text: "Professional approach, precise work and attention to every detail.",
    name: "Private client • Prague",
  },
  {
    text: "From design to installation, everything was clear, organized and premium.",
    name: "Interior project • Czech Republic",
  },
  {
    text: "The result looks expensive, functional and tailored to our lifestyle.",
    name: "Kitchen project • Europe",
  },
];

const filters = [
  { key: "all", label: "All" },
  { key: "kitchen", label: "Kitchens" },
  { key: "wardrobe", label: "Wardrobes" },
  { key: "custom", label: "Custom furniture" },
];

function euro(n: number) {
  return `€${Math.round(n).toLocaleString("en-US")}`;
}

function fadeUp(delay = 0) {
  return {
    initial: { opacity: 0, y: 42, filter: "blur(10px)" },
    whileInView: { opacity: 1, y: 0, filter: "blur(0px)" },
    viewport: { once: true, amount: 0.22 },
    transition: { duration: 0.85, delay, ease: [0.2, 0.8, 0.2, 1] },
  };
}

export default function Home() {
  const [lang, setLang] = useState<Lang>("en");
  const [theme, setTheme] = useState<Theme>("dark");
  const [menuOpen, setMenuOpen] = useState(false);
  const [filter, setFilter] = useState("all");
  const [galleryProject, setGalleryProject] = useState<(typeof initialProjects)[number] | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);

  const [calcStep, setCalcStep] = useState(1);
  const [calc, setCalc] = useState({
    layout: 1.25,
    length: 3.5,
    level: 1300,
    fronts: 0,
    worktop: 650,
    hardware: 900,
    lighting: 550,
    tall: 0,
    appliances: 0,
    region: 900,
  });

  const t = copy[lang];

  const { min, max, breakdown } = useMemo(() => {
    const cabinets = calc.length * calc.layout * calc.level + calc.fronts;
    const top = calc.length * calc.worktop;
    const hardware = calc.hardware;
    const options = calc.lighting + calc.tall + calc.appliances + calc.region + 700;
    const total = cabinets + top + hardware + options;
    return {
      min: total * 0.85,
      max: total * 1.25,
      breakdown: { cabinets, top, hardware, options },
    };
  }, [calc]);

  const filteredProjects = filter === "all" ? initialProjects : initialProjects.filter((p) => p.category === filter);

  const themeClasses =
    theme === "dark"
      ? "bg-maksterBlack text-maksterIvory"
      : "bg-[#f5efe6] text-[#111]";

  return (
    <main className={`${themeClasses} min-h-screen overflow-hidden`}>
      <Header
        lang={lang}
        setLang={setLang}
        theme={theme}
        setTheme={setTheme}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
        t={t}
        onAdmin={() => setAdminOpen(true)}
      />

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} t={t} />

      <section
        id="home"
        className="hero-video-effect relative isolate flex min-h-screen items-end bg-[url('/images/hero-kitchen.png')] bg-cover bg-center px-5 pb-10 pt-32 sm:px-8 lg:min-h-[920px] lg:px-16"
      >
        <div className="absolute left-5 top-28 z-10 flex items-center gap-3 text-xs uppercase tracking-[0.25em] text-maksterGoldLight sm:left-8 lg:left-16">
          <span className="h-2 w-2 animate-pulse rounded-full bg-maksterGoldLight shadow-gold" />
          Cinematic kitchen hero
        </div>

        <motion.div {...fadeUp()} className="relative z-10 max-w-6xl">
          <div className="mb-4 text-xs font-bold uppercase tracking-[0.35em] text-maksterGold">{t.heroEyebrow}</div>
          <h1 className="font-serifDisplay text-[13vw] font-normal uppercase leading-[0.88] tracking-tight text-white sm:text-7xl lg:text-[112px]">
            {t.heroTitle.split(" ").slice(0, 2).join(" ")}
            <br />
            <span className="text-maksterGoldLight">{t.heroTitle.split(" ").slice(2).join(" ")}</span>
          </h1>
          <p className="mt-6 max-w-xl text-base leading-8 text-white/86 sm:text-lg">{t.heroText}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a href="#portfolio" className="inline-flex h-14 items-center justify-center border border-maksterGold px-6 text-xs font-bold uppercase tracking-[0.22em] text-maksterGoldLight">
              {t.viewProjects} <ArrowRight className="ml-2 h-4 w-4" />
            </a>
            <a href="#calculator" className="inline-flex h-14 items-center justify-center bg-gradient-to-r from-maksterGoldLight to-maksterGold px-6 text-xs font-black uppercase tracking-[0.22em] text-black">
              {t.calculate}
            </a>
          </div>
        </motion.div>
      </section>

      <Section id="services" eyebrow={t.servicesEyebrow} title={t.servicesTitle}>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((service, i) => (
            <motion.div
              key={service[0]}
              {...fadeUp(i * 0.08)}
              className="group rounded-[28px] border border-maksterGold/20 bg-white/[0.035] p-6 shadow-2xl transition duration-500 hover:-translate-y-1 hover:border-maksterGold/55"
            >
              <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-full border border-maksterGold/50 text-maksterGoldLight">
                <Check className="h-6 w-6" />
              </div>
              <h3 className="mb-3 font-serifDisplay text-2xl text-maksterGoldLight">{service[0]}</h3>
              <p className="text-sm leading-7 text-maksterMuted">{service[1]}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      <Section id="about" eyebrow="About" title={t.aboutTitle}>
        <div className="grid gap-8 lg:grid-cols-2 lg:items-center">
          <motion.div {...fadeUp()}>
            <p className="text-lg leading-9 text-maksterMuted">{t.aboutText}</p>
            <div className="mt-8 grid grid-cols-3 gap-3">
              {["10+ years", "Prague", "Europe"].map((item) => (
                <div key={item} className="rounded-2xl border border-maksterGold/20 p-4 text-center">
                  <div className="font-serifDisplay text-2xl text-maksterGoldLight">{item}</div>
                </div>
              ))}
            </div>
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="relative min-h-[420px] overflow-hidden rounded-[34px] border border-maksterGold/20">
            <Image src="/images/hero-kitchen.png" alt="Makster Atelier kitchen" fill className="object-cover" />
          </motion.div>
        </div>
      </Section>

      <Section id="process" eyebrow="Process" title={t.processTitle}>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {process.map((step, i) => (
            <motion.div key={step} {...fadeUp(i * 0.08)} className="rounded-[28px] border border-maksterGold/20 p-6">
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-full border border-maksterGold text-maksterGoldLight">
                {i + 1}
              </div>
              <h3 className="font-serifDisplay text-2xl text-maksterGoldLight">{step}</h3>
              <p className="mt-3 text-sm leading-7 text-maksterMuted">
                {["We discuss your space, needs and budget.", "We prepare concept, materials and technical solution.", "Your furniture is manufactured with precision.", "We deliver, install and check the final result."][i]}
              </p>
            </motion.div>
          ))}
        </div>
      </Section>

      <Section id="portfolio" eyebrow="Portfolio" title={t.portfolioTitle}>
        <div className="no-scrollbar mb-6 flex gap-3 overflow-x-auto">
          {filters.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`whitespace-nowrap rounded-full border px-5 py-3 text-xs font-bold uppercase tracking-[0.16em] ${
                filter === f.key
                  ? "border-maksterGold bg-maksterGold text-black"
                  : "border-maksterGold/30 text-maksterGoldLight"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="masonry">
          {filteredProjects.map((project) => (
            <motion.button
              key={project.id}
              {...fadeUp()}
              onClick={() => setGalleryProject(project)}
              className={`masonry-item relative w-full overflow-hidden rounded-[30px] border border-maksterGold/20 ${project.height}`}
            >
              <Image src={project.image} alt={project.title} fill className="object-cover transition duration-700 hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent" />
              <div className="absolute bottom-5 left-5 font-serifDisplay text-3xl text-maksterGoldLight">{project.title}</div>
            </motion.button>
          ))}
        </div>
      </Section>

      <CalculatorSection
        t={t}
        calc={calc}
        setCalc={setCalc}
        calcStep={calcStep}
        setCalcStep={setCalcStep}
        min={min}
        max={max}
        breakdown={breakdown}
      />

      <Section id="booking" eyebrow="Free Measurement" title={t.bookingTitle}>
        <div className="grid gap-8 lg:grid-cols-2">
          <motion.div {...fadeUp()} className="rounded-[34px] border border-maksterGold/20 bg-white/[0.035] p-6">
            <p className="mb-6 leading-8 text-maksterMuted">{t.bookingText}</p>
            <div className="grid gap-4">
              <input className="h-14 rounded-2xl border border-maksterGold/25 bg-black/30 px-4 outline-none" placeholder="Your name" />
              <input className="h-14 rounded-2xl border border-maksterGold/25 bg-black/30 px-4 outline-none" placeholder="Phone / WhatsApp" />
              <select className="h-14 rounded-2xl border border-maksterGold/25 bg-black/30 px-4 outline-none">
                <option>Kitchen</option>
                <option>Wardrobe</option>
                <option>Walk-in closet</option>
                <option>Custom furniture</option>
              </select>
              <textarea className="min-h-28 rounded-2xl border border-maksterGold/25 bg-black/30 p-4 outline-none" placeholder="Briefly describe your project" />
              <a href="mailto:maysterww@gmail.com?subject=Free consultation request" className="inline-flex h-14 items-center justify-center bg-maksterGold text-xs font-black uppercase tracking-[0.18em] text-black">
                <Send className="mr-2 h-4 w-4" /> {t.quote}
              </a>
            </div>
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="rounded-[34px] border border-maksterGold/20 p-6">
            <div className="mb-4 text-maksterGoldLight">Quick contact</div>
            <div className="grid gap-4">
              <a href="https://wa.me/420720472811" className="flex h-16 items-center justify-center rounded-2xl border border-maksterGold/25 text-maksterGoldLight">
                <MessageCircle className="mr-3 h-5 w-5" /> WhatsApp
              </a>
              <a href="https://m.me/maksteratelier" className="flex h-16 items-center justify-center rounded-2xl border border-maksterGold/25 text-maksterGoldLight">
                <MessageCircle className="mr-3 h-5 w-5" /> Messenger
              </a>
              <a href="tel:+420720472811" className="flex h-16 items-center justify-center rounded-2xl border border-maksterGold/25 text-maksterGoldLight">
                <Phone className="mr-3 h-5 w-5" /> +420 720 472 811
              </a>
            </div>
          </motion.div>
        </div>
      </Section>

      <Section id="area" eyebrow="Service Area" title={t.areaTitle}>
        <div className="relative h-[360px] overflow-hidden rounded-[34px] border border-maksterGold/20 bg-[radial-gradient(circle_at_50%_50%,rgba(200,155,77,.20)_0_3px,transparent_4px),linear-gradient(135deg,#111,#050505)]">
          <div className="absolute inset-12 rounded-full border border-maksterGold/20 shadow-[0_0_0_60px_rgba(200,155,77,.04),0_0_0_120px_rgba(200,155,77,.025)]" />
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center font-serifDisplay text-3xl text-maksterGoldLight">
            📍<br />Prague
          </div>
        </div>
      </Section>

      <Section id="founders" eyebrow="Founders" title={t.foundersTitle}>
        <div className="grid gap-8 lg:grid-cols-2 lg:items-center">
          <motion.div {...fadeUp()} className="relative min-h-[520px] overflow-hidden rounded-[34px] border border-maksterGold/20">
            <Image src="/images/founders.png" alt="Founders of Makster Atelier" fill className="object-cover" />
          </motion.div>
          <motion.div {...fadeUp(0.15)} className="space-y-4">
            <Founder name="Vyacheslav Mayster" role="Founder & Managing Director" />
            <Founder name="Yuriy Maksimchenko" role="Founder & Technical Director" />
          </motion.div>
        </div>
      </Section>

      <Section id="reviews" eyebrow="Reviews" title={t.reviewsTitle}>
        <div className="grid gap-4 md:grid-cols-3">
          {reviews.map((review, i) => (
            <motion.div key={review.name} {...fadeUp(i * 0.08)} className="rounded-[28px] border border-maksterGold/20 p-6">
              <div className="mb-4 flex gap-1 text-maksterGoldLight">{Array.from({ length: 5 }).map((_, n) => <Star key={n} className="h-4 w-4 fill-current" />)}</div>
              <p className="leading-8 text-maksterMuted">{review.text}</p>
              <div className="mt-5 font-bold text-white">{review.name}</div>
            </motion.div>
          ))}
        </div>
      </Section>

      <footer className="border-t border-maksterGold/15 px-5 py-10 text-center text-sm text-maksterMuted">
        MAKSTER ATELIER — Crafted Around Your Life
      </footer>

      <GalleryModal project={galleryProject} onClose={() => setGalleryProject(null)} />
      <AdminPanel open={adminOpen} onClose={() => setAdminOpen(false)} t={t} />
    </main>
  );
}

function Header({ lang, setLang, theme, setTheme, menuOpen, setMenuOpen, t, onAdmin }: any) {
  return (
    <header className="fixed left-0 right-0 top-0 z-50">
      <div className="mx-auto flex h-20 max-w-[1600px] items-center justify-between px-5 lg:px-10">
        <a href="#home" className="glass flex items-center gap-3 rounded-full px-3 py-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-full border border-maksterGold font-serifDisplay text-2xl tracking-[-.18em] text-maksterGoldLight">MA</div>
          <div className="hidden sm:block">
            <div className="font-serifDisplay text-sm tracking-[0.25em] text-maksterGoldLight">MAKSTER ATELIER</div>
            <div className="text-[9px] uppercase tracking-[0.22em] text-maksterGold">Bespoke Furniture & Interiors</div>
          </div>
        </a>

        <nav className="glass hidden rounded-full px-4 py-3 lg:flex">
          {t.nav.map((item: string, i: number) => {
            const hrefs = ["#services", "#portfolio", "#calculator", "#booking", "#reviews"];
            return (
              <a key={item} href={hrefs[i]} className="px-4 text-xs uppercase tracking-[0.18em] text-maksterGoldLight/85 hover:text-maksterGoldLight">
                {item}
              </a>
            );
          })}
        </nav>

        <div className="glass flex items-center gap-2 rounded-full p-2">
          {(["en", "cz", "ru"] as Lang[]).map((l) => (
            <button key={l} onClick={() => setLang(l)} className={`rounded-full px-2.5 py-1 text-xs uppercase ${lang === l ? "bg-maksterGold text-black" : "text-maksterGoldLight"}`}>
              {l}
            </button>
          ))}
          <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="rounded-full p-2 text-maksterGoldLight">
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <button onClick={onAdmin} className="hidden rounded-full p-2 text-maksterGoldLight sm:block">
            <Settings className="h-4 w-4" />
          </button>
          <button onClick={() => setMenuOpen(!menuOpen)} className="rounded-full p-2 text-maksterGoldLight lg:hidden">
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}

function MobileMenu({ open, onClose, t }: any) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] bg-black/90 p-6 lg:hidden">
          <button onClick={onClose} className="absolute right-5 top-5 text-maksterGoldLight"><X /></button>
          <div className="mt-24 grid gap-6">
            {t.nav.map((item: string, i: number) => {
              const hrefs = ["#services", "#portfolio", "#calculator", "#booking", "#reviews"];
              return (
                <a key={item} onClick={onClose} href={hrefs[i]} className="font-serifDisplay text-4xl text-maksterGoldLight">
                  {item}
                </a>
              );
            })}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Section({ id, eyebrow, title, children }: any) {
  return (
    <section id={id} className="px-5 py-20 sm:px-8 lg:px-16 lg:py-28">
      <div className="mx-auto max-w-[1500px]">
        <motion.div {...fadeUp()} className="mb-10">
          <div className="mb-4 text-xs font-bold uppercase tracking-[0.35em] text-maksterGold">{eyebrow}</div>
          <h2 className="max-w-4xl font-serifDisplay text-4xl font-normal leading-tight text-maksterGoldLight sm:text-5xl lg:text-7xl">{title}</h2>
        </motion.div>
        {children}
      </div>
    </section>
  );
}

function CalculatorSection({ t, calc, setCalc, calcStep, setCalcStep, min, max, breakdown }: any) {
  const totalSteps = 9;
  const next = () => setCalcStep((s: number) => Math.min(totalSteps, s + 1));
  const back = () => setCalcStep((s: number) => Math.max(1, s - 1));

  return (
    <Section id="calculator" eyebrow="Kitchen Price Calculator" title={t.calculatorTitle}>
      <div className="grid gap-8 xl:grid-cols-[1.05fr_.95fr]">
        <motion.div {...fadeUp()} className="rounded-[34px] border border-maksterGold/20 bg-white/[0.035] p-5 sm:p-7">
          <p className="mb-8 leading-8 text-maksterMuted">{t.calculatorText}</p>

          <div className="mb-7 h-1 overflow-hidden rounded-full bg-white/10">
            <motion.div className="h-full bg-gradient-to-r from-maksterGold to-maksterGoldLight" animate={{ width: `${(calcStep / totalSteps) * 100}%` }} />
          </div>

          <CalculatorStep step={calcStep} calc={calc} setCalc={setCalc} />

          <div className="mt-8 flex gap-3">
            <button onClick={back} className="h-14 flex-1 border border-maksterGold/40 text-xs font-bold uppercase tracking-[0.18em] text-maksterGoldLight">
              <ChevronLeft className="mr-1 inline h-4 w-4" /> Back
            </button>
            {calcStep < totalSteps ? (
              <button onClick={next} className="h-14 flex-1 bg-maksterGold text-xs font-black uppercase tracking-[0.18em] text-black">
                Next <ChevronRight className="ml-1 inline h-4 w-4" />
              </button>
            ) : (
              <a href="mailto:maysterww@gmail.com?subject=Kitchen estimate request" className="flex h-14 flex-1 items-center justify-center bg-maksterGold text-xs font-black uppercase tracking-[0.18em] text-black">
                {t.quote}
              </a>
            )}
          </div>
        </motion.div>

        <motion.div {...fadeUp(0.15)} className="sticky top-28 h-fit rounded-[34px] border border-maksterGold/20 bg-black/30 p-6">
          <div className="mb-2 text-xs uppercase tracking-[0.25em] text-maksterGold">Estimated budget</div>
          <div className="font-serifDisplay text-4xl text-maksterGoldLight sm:text-5xl">{euro(min)} – {euro(max)}</div>
          <div className="mt-6 grid gap-3">
            <Breakdown label="Cabinets & fronts" value={breakdown.cabinets} />
            <Breakdown label="Worktop" value={breakdown.top} />
            <Breakdown label="Hardware & mechanisms" value={breakdown.hardware} />
            <Breakdown label="Options & installation reserve" value={breakdown.options} />
          </div>
          <div className="mt-6 rounded-2xl border border-maksterGold/20 bg-maksterGold/5 p-4 text-sm leading-7 text-maksterMuted">
            {t.notIncluded}
          </div>
        </motion.div>
      </div>
    </Section>
  );
}

function CalculatorStep({ step, calc, setCalc }: any) {
  const set = (key: string, value: number) => setCalc((c: any) => ({ ...c, [key]: value }));
  const toggle = (key: string, value: number) => setCalc((c: any) => ({ ...c, [key]: c[key] ? 0 : value }));

  const option = (label: string, desc: string, selected: boolean, onClick: () => void) => (
    <button onClick={onClick} className={`w-full rounded-3xl border p-5 text-left transition ${selected ? "border-maksterGold bg-maksterGold/10" : "border-maksterGold/20 bg-black/20"}`}>
      <div className="font-serifDisplay text-2xl text-maksterGoldLight">{label}</div>
      <div className="mt-2 text-sm leading-6 text-maksterMuted">{desc}</div>
    </button>
  );

  if (step === 1) return <StepLayout q="1. What kitchen shape do you need?">
    {option("Straight kitchen", "One wall layout. Clean and efficient.", calc.layout === 1, () => set("layout", 1))}
    {option("L-shape kitchen", "Corner layout with more storage.", calc.layout === 1.25, () => set("layout", 1.25))}
    {option("U-shape kitchen", "Maximum working surface and storage.", calc.layout === 1.45, () => set("layout", 1.45))}
    {option("Kitchen with island", "Premium open-space solution.", calc.layout === 1.65, () => set("layout", 1.65))}
  </StepLayout>;

  if (step === 2) return <StepLayout q="2. How long is your kitchen?">
    <div className="rounded-3xl border border-maksterGold/20 p-6">
      <div className="font-serifDisplay text-5xl text-maksterGoldLight">{calc.length.toFixed(1)} m</div>
      <input type="range" min={2} max={9} step={0.1} value={calc.length} onChange={(e) => set("length", Number(e.target.value))} className="mt-8 w-full accent-maksterGold" />
      <p className="mt-5 text-sm leading-7 text-maksterMuted">For L-shape or U-shape, count all sides together.</p>
    </div>
  </StepLayout>;

  if (step === 3) return <StepLayout q="3. Which style level do you prefer?">
    {option("Standard", "Quality materials, practical solution.", calc.level === 900, () => set("level", 900))}
    {option("Premium", "Best balance of design, quality and durability.", calc.level === 1300, () => set("level", 1300))}
    {option("Luxury", "High-end materials and refined details.", calc.level === 1850, () => set("level", 1850))}
  </StepLayout>;

  if (step === 4) return <StepLayout q="4. Choose the fronts">
    {option("Laminate fronts", "Durable, elegant and cost-effective.", calc.fronts === 0, () => set("fronts", 0))}
    {option("Painted / lacquered fronts", "Smooth premium look.", calc.fronts === 950, () => set("fronts", 950))}
    {option("Veneer / premium fronts", "Luxury natural or designer finish.", calc.fronts === 1500, () => set("fronts", 1500))}
  </StepLayout>;

  if (step === 5) return <StepLayout q="5. Choose your worktop">
    {option("Laminate", "Practical everyday surface.", calc.worktop === 250, () => set("worktop", 250))}
    {option("Compact / premium laminate", "Modern thin premium look.", calc.worktop === 650, () => set("worktop", 650))}
    {option("Stone / quartz", "Premium surface with high durability.", calc.worktop === 1150, () => set("worktop", 1150))}
  </StepLayout>;

  if (step === 6) return <StepLayout q="6. Hardware and mechanisms">
    {option("Standard hardware", "Reliable hinges and drawers.", calc.hardware === 450, () => set("hardware", 450))}
    {option("Premium hardware", "Blum / Hettich level, soft close.", calc.hardware === 900, () => set("hardware", 900))}
    {option("Luxury hardware", "Premium drawers, organizers and mechanisms.", calc.hardware === 1500, () => set("hardware", 1500))}
  </StepLayout>;

  if (step === 7) return <StepLayout q="7. Extra options">
    {option("LED lighting", "Integrated warm lighting.", calc.lighting > 0, () => toggle("lighting", 550))}
    {option("Tall cabinets", "Pantry or built-in appliance units.", calc.tall > 0, () => toggle("tall", 700))}
    {option("Appliances package", "Approximate appliance budget reserve.", calc.appliances > 0, () => toggle("appliances", 2500))}
  </StepLayout>;

  if (step === 8) return <StepLayout q="8. Installation area">
    {option("Prague", "Measurement, delivery and basic installation reserve.", calc.region === 900, () => set("region", 900))}
    {option("Czech Republic", "Projects outside Prague.", calc.region === 1250, () => set("region", 1250))}
    {option("Europe", "International project reserve.", calc.region === 1900, () => set("region", 1900))}
  </StepLayout>;

  return <StepLayout q="9. Your estimated kitchen budget">
    <div className="rounded-3xl border border-maksterGold/20 bg-maksterGold/5 p-6">
      <div className="mb-3 text-xs uppercase tracking-[0.25em] text-maksterGold">Ready</div>
      <p className="leading-8 text-maksterMuted">The estimate is ready. Check the budget breakdown on the right side and request a detailed quote.</p>
    </div>
  </StepLayout>;
}

function StepLayout({ q, children }: any) {
  return (
    <div>
      <h3 className="mb-6 font-serifDisplay text-3xl text-maksterGoldLight">{q}</h3>
      <div className="grid gap-4">{children}</div>
    </div>
  );
}

function Breakdown({ label, value }: any) {
  return (
    <div className="flex items-center justify-between border-b border-maksterGold/10 py-3 text-sm">
      <span className="text-maksterMuted">{label}</span>
      <b className="text-maksterGoldLight">{euro(value)}</b>
    </div>
  );
}

function Founder({ name, role }: { name: string; role: string }) {
  return (
    <div className="rounded-[28px] border border-maksterGold/20 p-6">
      <div className="font-serifDisplay text-3xl text-maksterGoldLight">{name}</div>
      <div className="mt-3 text-xs uppercase tracking-[0.22em] text-white">{role}</div>
    </div>
  );
}

function GalleryModal({ project, onClose }: any) {
  return (
    <AnimatePresence>
      {project && (
        <motion.div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <button onClick={onClose} className="absolute right-5 top-5 rounded-full border border-maksterGold/40 p-3 text-maksterGoldLight"><X /></button>
          <div className="w-full max-w-5xl">
            <div className="relative h-[70vh] overflow-hidden rounded-[34px] border border-maksterGold/20">
              <Image src={project.image} alt={project.title} fill className="object-cover" />
            </div>
            <div className="mt-5 font-serifDisplay text-4xl text-maksterGoldLight">{project.title}</div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function AdminPanel({ open, onClose, t }: any) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/92 p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="max-h-[90vh] w-full max-w-3xl overflow-auto rounded-[34px] border border-maksterGold/25 bg-[#0b0b0b] p-6">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="font-serifDisplay text-3xl text-maksterGoldLight">{t.admin}</h3>
              <button onClick={onClose} className="text-maksterGoldLight"><X /></button>
            </div>
            <p className="mb-6 leading-8 text-maksterMuted">
              Demo admin panel. In production, this connects to a CMS or CRM where you can add projects, replace photos, publish reviews, edit calculator prices and write blog articles.
            </p>
            <div className="grid gap-4 md:grid-cols-2">
              {["Projects", "Photos", "Reviews", "Calculator prices", "Blog articles", "CRM leads"].map((item) => (
                <div key={item} className="rounded-2xl border border-maksterGold/20 p-5 text-maksterGoldLight">{item}</div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

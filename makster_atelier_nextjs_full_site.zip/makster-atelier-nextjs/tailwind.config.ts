import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        maksterBlack: "#050505",
        maksterPanel: "#121212",
        maksterGold: "#C89B4D",
        maksterGoldLight: "#E7C678",
        maksterIvory: "#F5EFE6",
        maksterMuted: "#B7B0A5",
      },
      fontFamily: {
        serifDisplay: ["Georgia", "Times New Roman", "serif"],
      },
      boxShadow: {
        gold: "0 0 50px rgba(200,155,77,0.25)",
      },
    },
  },
  plugins: [],
};
export default config;
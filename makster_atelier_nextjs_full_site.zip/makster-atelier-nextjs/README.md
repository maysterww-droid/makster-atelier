# MAKSTER ATELIER — Next.js Premium Website

Полноценный адаптивный сайт для MAKSTER ATELIER.

## Что включено

- Next.js + React + TypeScript
- Tailwind CSS
- Framer Motion анимации
- Адаптивность: mobile / tablet / desktop
- Hero с видео-эффектом Ken Burns
- Портфолио с фильтрами
- Masonry-сетка на десктопе
- Fullscreen gallery
- Онлайн-калькулятор кухни
- Онлайн-заявка на консультацию / замер
- WhatsApp и Messenger кнопки
- Карта зоны работы
- Блок отзывов
- Переключение EN / CZ / RU без перезагрузки
- Светлая / тёмная тема
- SEO metadata
- PWA manifest
- Demo admin panel

## Запуск

```bash
npm install
npm run dev
```

Открыть:

```bash
http://localhost:3000
```

## Сборка

```bash
npm run build
npm run start
```

## Как заменить фото

Положить реальные изображения в:

```bash
/public/images/
```

И заменить пути в файле:

```bash
app/page.tsx
```

## Что ещё подключить для production

- CMS: Sanity / Strapi / Directus
- CRM: Airtable / HubSpot / custom CRM
- Email forms: Resend / Formspree / Make.com
- Analytics: Google Analytics / Meta Pixel
- Deployment: Vercel